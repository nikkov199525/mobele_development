# Архитектура проекта loginApp

## Структура MVC

```
loginApp/
│
├── 📁 Models/                      # Модели данных
│   ├── User.swift                  # Модель пользователя
│   └── Product.swift               # Модель товара (GoodsModel)
│
├── 📁 Views/                       # Представления (UI)
│   └── Base.lproj/
│       ├── Main.storyboard         # Основной интерфейс
│       └── LaunchScreen.storyboard # Экран запуска
│
├── 📁 Controllers/                 # Контроллеры (логика UI)
│   ├── LoginViewController.swift   # Экран авторизации
│   ├── ProductsViewController.swift # Экран каталога товаров
│   └── CartViewController.swift    # Экран корзины
│
├── 📁 Services/                    # Бизнес-логика
│   └── CartManager.swift           # Менеджер корзины (Singleton)
│
├── 📁 SupportingFiles/             # Вспомогательные файлы
│   ├── AppDelegate.swift           # Жизненный цикл приложения
│   ├── SceneDelegate.swift         # Управление сценами
│   └── Assets.xcassets/            # Ресурсы (изображения, цвета)
│
└── 📄 README.md                    # Документация проекта
```

## Слои приложения

### 1. Model Layer (Модели)
**Ответственность:** Данные и бизнес-правила

- `User.swift` - структура пользователя с полями:
  - id, login, password, name, avatar, email, phone, address, about
  - Метод `mockUser()` для тестовых данных

- `Product.swift` (GoodsModel) - структура товара с полями:
  - id, title, price, description, image, quantity
  - Метод `mockGoods()` - 6 товаров Apple

### 2. View Layer (Представления)
**Ответственность:** Визуальное представление

- `Main.storyboard` - содержит 3 экрана:
  - LoginViewController scene
  - ProductsViewController scene (в NavigationController)
  - CartViewController scene

### 3. Controller Layer (Контроллеры)
**Ответственность:** Связь Model ↔ View, обработка событий

#### LoginViewController
- Проверка логина/пароля
- Навигация на главный экран
- Восстановление credentials

#### ProductsViewController
- Отображение каталога товаров в UITableView
- Добавление товаров в корзину (через CartManager)
- Переход в корзину

#### CartViewController
- Отображение корзины в UITableView
- Удаление товаров (swipe to delete)
- Расчет и отображение общей суммы
- Оформление заказа

### 4. Service Layer (Сервисы)
**Ответственность:** Бизнес-логика, не связанная с UI

#### CartManager (Singleton)
```swift
// Глобальный доступ
CartManager.shared

// API методы:
- addToCart(_ item: GoodsModel)      // Добавить товар
- removeFromCart(at index: Int)       // Удалить товар
- getTotalPrice() -> Double           // Общая сумма
- clearCart()                         // Очистить корзину
- getItemsCount() -> Int              // Количество товаров
```

## Поток данных (Data Flow)

```
1. Авторизация:
   User (Model) ← LoginViewController → Main.storyboard (View)
                            ↓
                  ProductsViewController

2. Добавление в корзину:
   ProductsViewController → CartManager.shared.addToCart()
                                      ↓
                              cartItems: [GoodsModel]

3. Отображение корзины:
   CartViewController ← CartManager.shared.cartItems
```

## Паттерны проектирования

### 1. MVC (Model-View-Controller)
- **Разделение ответственности** между данными, UI и логикой

### 2. Singleton
- `CartManager.shared` - единый экземпляр менеджера корзины
- Общее состояние корзины для всех экранов

### 3. Delegation
- UITableViewDelegate, UITableViewDataSource
- Обработка событий таблиц

### 4. Factory Method
- `User.mockUser()` и `GoodsModel.mockGoods()`
- Создание тестовых данных

## Принципы SOLID

### S - Single Responsibility (Единственная ответственность)
- Каждый класс отвечает за одну задачу
- CartManager - только управление корзиной
- LoginViewController - только авторизация

### O - Open/Closed (Открыт для расширения, закрыт для изменения)
- Легко добавить новые товары через `mockGoods()`
- Легко добавить новые поля в User без изменения существующих

### L - Liskov Substitution (Подстановка Лисков)
- Все UIViewController соблюдают контракт базового класса

### I - Interface Segregation (Разделение интерфейсов)
- UITableViewDataSource и UITableViewDelegate разделены
- Каждый протокол отвечает за свою часть

### D - Dependency Inversion (Инверсия зависимостей)
- Controllers зависят от абстракции (CartManager), а не от конкретной реализации


```
LoginViewController
    ↓ userName
ProductsViewController
    ↓ addToCart()
CartManager (Singleton)
    ↑ cartItems
CartViewController
```

